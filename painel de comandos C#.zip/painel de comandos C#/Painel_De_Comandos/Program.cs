﻿using System;

namespace Painel_De_Comandos
{
    class Program
    {
        static void Main(string[] args)
        {
        
        }
        static void Todos_Os_Calculos(string[] args)
        {
            int n1,n2,adi,sub,mult,div;
            Console.Write("Digite um número: ");
            n1 = int.Parse(Console.ReadLine());
            Console.Write("Digite outro número: ");
            n2 = int.Parse(Console.ReadLine());

            adi = n1 + n2;
            sub = n1 - n2;
            mult = n1 * n2;
            div = n1 / n2;

            Console.Write("Resultado: " + adi + sub + mult + div);
        }
        static void Anteecssor_E_Sucessor(string[] args)
        {
            int n,ant,suc;

            Console.Write("Digite um número: \n");
            n = int.Parse(Console.ReadLine());

            ant = n - 1;
            suc = n + 1;

            Console.Write("Antecessor: " + ant + "Sucessor: " + suc);

        }
         static void area_do_triangulo(string[] args)
        {
            int bas,alt,calc;

            Console.Write("Digite o valor da base: \n");
            bas = int.Parse(Console.ReadLine());
            Console.Write("Escreva o valor da altura do triangulo: \n");
            alt = int.Parse(Console.ReadLine());

            calc = (bas * alt) / 2;

            Console.Write("Result: " + calc);


        }
        static void media_aritimetica(string[] args)
        {
            int n1, n2, n3, n4, med;

            Console.Write("Digite o valor do 1° número: ");
            n1 = int.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 2° número: ");
            n2 = int.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 3° número: ");
            n3 = int.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 4° número: ");
            n4 = int.Parse(Console.ReadLine());

            med = (n1 + n2 + n3 + n4) / 4;

            Console.Write("A media dos quatro valores é equivalente a: " + med);
        }
        static void Compara_Numeros(string[] args)
        {
            int n1, n2;

            Console.Write("Digite o valor do 1° número: ");
            n1 = int.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 2° número: ");
            n2 = int.Parse(Console.ReadLine());

            if (n1 > n2 )
            {
                Console.Write("O " + n1 + "é o maior");
            }
            else
            {
                Console.Write("O " + n2 + "é o maior");
            }
        }
        static void Tabuada(string[] args)
        {
            int n1, A, B, C, D, E, F, G, H, I, J;

            Console.Write("Digite um número: ");
            n1 = int.Parse(Console.ReadLine());

            A = n1 * 1;
            B = n1 * 2;
            C = n1 * 3;
            D = n1 * 4;
            E = n1 * 5;
            F = n1 * 6;
            G = n1 * 7;
            H = n1 * 8;
            I = n1 * 9;
            J = n1 * 10;
            
        }
    }
}
